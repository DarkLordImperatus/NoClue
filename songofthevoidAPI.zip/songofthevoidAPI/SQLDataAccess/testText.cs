﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SQLDataAccess
{
    public partial class testText
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public string Body { get; set; }
        public byte Media { get; set; }
        public string Created_By { get; set; }
        public DateTime Created_Time { get; set; }
        public DateTime Last_Modified { get; set; }
    }
}
